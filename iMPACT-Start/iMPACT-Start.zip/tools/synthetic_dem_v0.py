# -*- coding: utf-8 -*-
"""
Created on Sun May 12 12:19:52 2024

@author: andro
"""

import matplotlib.pyplot as plt  # Library for plotting
from matplotlib import cm  # Colormap module for color representations
import numpy as np
from tools.flow_accumulation import flow_accumulation_D8

def synthetic_dem(a=0.3, b=3, c=3, resol=50, pert=0, x0=1.0, x1=1.6, y0=1.8, y1=2.3):
    """
    Generate a synthetic digital elevation model (DEM).

    Parameters:
    - a, b, c: Parameters for controlling the shape of the terrain.
    - resol: Resolution of the DEM grid.
    - pert: Amount of random perturbation added to the DEM.
    - x0, x1, y0, y1: Range of x and y values for generating the DEM grid.

    Returns:
    - dem: Synthetic DEM array.
    """

    # Create meshgrid for x and y coordinates based on specified range and resolution
    x, y = np.meshgrid(np.arange(x0, x1 * np.pi, np.pi / resol), np.arange(y0, y1 * np.pi, np.pi / resol))
    
    # Generate DEM using mathematical formula
    dem = np.cos(x) * np.cos(y) + a * np.cos(b * x) * np.sin(c * y)
    
    # Add random perturbation to the DEM
    dem = dem + np.random.normal(0, pert, dem.shape)
    
    return dem

def interactive_synthetic_dem(a=0.1, b=5, c=3, resol=16, pert=0):
    """
    Plot the synthetic digital elevation model (DEM) in 3-D.

    Parameters:
    - a, b, c: Parameters for controlling the shape of the terrain.
    - resol: Resolution of the DEM grid.
    - pert: Amount of random perturbation added to the DEM.
    """

    # Define range for x and y coordinates
    x0 = 1.0
    x1 = 1.6
    y0 = 1.8
    y1 = 2.3
    
    # Set elevation and azimuth angles for 3D plot
    elev = 30
    azim = 230
    
    # Generate synthetic DEM
    dem = synthetic_dem(a, b, c, resol, pert, x0, x1, y0, y1)

    # Create meshgrid for x and y coordinates
    x, y = np.meshgrid(np.arange(dem.shape[1]), np.arange(dem.shape[0]))
    
    # Create figure
    fig = plt.figure(figsize=(15, 7))
    fig.suptitle('Synthetic DEM')
    
    # First subplot: 2D plot
    #ax = fig.add_subplot(1, 3, 1)
    #mesh = ax.imshow(np.flip(dem, 0), cmap=cm.coolwarm)
    #ax.set_xlabel('X axis')
    #ax.set_ylabel('Y axis')
    #fig.colorbar(mesh)
    
    # Second subplot: 3D plot
    ax = fig.add_subplot(1, 2, 1, projection='3d')
    ax.plot_surface(x, y, np.flipud(dem),
                           rstride=1,
                           cstride=1,
                           cmap = 'viridis',
                           linewidth=0.,
                           antialiased=True)
    
    # Set view angle for 3D plot
    ax.view_init(elev=elev, azim=azim)
    ax.set_xlabel('X axis')
    ax.set_ylabel('Y axis')
    ax.set_zlabel('Elevation')
    
    # Third subplot: flow accumulation
    fd_D8,fa_D8,ix_D8,ixc_D8 = flow_accumulation_D8(dem)
    ax = fig.add_subplot(1, 2, 2)
    mesh = ax.imshow(fa_D8, cmap=cm.coolwarm)
    ax.set_xlabel('X axis')
    ax.set_ylabel('Y axis')
    fig.colorbar(mesh) 
    plt.show()