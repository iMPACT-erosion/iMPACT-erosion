def soil_texture_calculator(silt, clay):
    """
    Classifies soil texture based on USDA soil texture triangle.
    
    Parameters:
        sand (float): Percentage of sand (0-100).
        clay (float): Percentage of clay (0-100).
    
    Returns:
        str: Soil texture classification.
    """
    if not (0 <= silt <= 100 and 0 <= clay <= 100):
        raise ValueError("Silt and clay percentages must be between 0 and 100.")
    
    sand = 100 - silt - clay
    
    if silt < 0:
        raise ValueError("The sum of sand and clay percentages cannot exceed 100.")
    
    # Classify based on USDA soil texture triangle
    if clay >= 40:
        if sand > 45:
            return "Sandy Clay"
        elif silt >= 40:
            return "Silty Clay"
        else:
            return "Clay"
    
    elif clay >= 27 and clay < 40:
        if sand < 20:
            return "Silty Clay Loam"
        elif sand >= 20 and sand < 40:
            return "Clay loam"
        elif sand >=40 and clay >= 36:
            return "Sandy clay"
        else:
            return "Sandy clay loam"
        
    elif clay >= 20 and clay < 27:
        if silt < 28:
            return "Sandy clay loam"
        elif silt >= 28 and silt < 50:
            return "Loam"
        else:
            return "Silt loam"
    
    if clay < 20:
        if sand >= 85:
            return "Sand"
        elif sand < 85 and sand >= 50:
            return "Sandy Loam"
        elif sand < 50:
            if clay >= 7 and silt < 50:
                return "Loam"
            elif clay < 7 and silt < 50:
                return "Sandy loam"
            elif clay < 14 and silt >= 80:
                return "Silt"
            else:
                return "Silt loam"

